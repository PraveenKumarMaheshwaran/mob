package com.cg.mobapp.bean;

public class MobileDetails {
private int MobileId;
private String MobileName;
private int MobilePrice;
private int MobileQty;
private int Max;
private int Min;
public int getMax() {
	return Max;
}
public void setMax(int max) {
	Max = max;
}
public int getMin() {
	return Min;
}
public void setMin(int min) {
	Min = min;
}
public int getMobileId() {
	return MobileId;
}
public void setMobileId(int mobileId) {
	MobileId = mobileId;
}
public String getMobileName() {
	return MobileName;
}
public void setMobileName(String mobileName) {
	MobileName = mobileName;
}
public int getMobilePrice() {
	return MobilePrice;
}
public void setMobilePrice(int mobilePrice) {
	MobilePrice = mobilePrice;
}
public int getMobileQty() {
	return MobileQty;
}
public void setMobileQty(int mobileQty) {
	MobileQty = mobileQty;
}
@Override
public String toString() {
	return " Mobile Details "
			+ " \n Mobile Id :" + MobileId + ""
					+ " \n Mobile Name :" + MobileName
			+ " \n Mobile Price :" + MobilePrice + ""
					+ " \n Mobile Quantity :" + MobileQty;
}

}
