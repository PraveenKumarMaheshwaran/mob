package com.cg.mobapp.bean;

import java.sql.Date;
import java.time.LocalDate;

public class MobileCustomer {
private String CustomerName;
private String MailID;
private String PhoneNumber;
private int MobileId;
private int PurchaseId;
private int Quantity;
public int getQuantity() {
	return Quantity;
}
public void setQuantity(int quantity) {
	Quantity = quantity;
}
LocalDate PurchaseDate;
public String getCustomerName() {
	return CustomerName;
}
public void setCustomerName(String customerName) {
	CustomerName = customerName;
}
public String getMailID() {
	return MailID;
}
public void setMailID(String mailID) {
	MailID = mailID;
}
public String getPhoneNumber() {
	return PhoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	PhoneNumber = phoneNumber;
}
public int getMobileId() {
	return MobileId;
}
public void setMobileId(int mobileId) {
	MobileId = mobileId;
}
public int getPurchaseId() {
	return PurchaseId;
}
public void setPurchaseId(int purchaseId) {
	PurchaseId = purchaseId;
}
public LocalDate getPurchaseDate() {
	return PurchaseDate;
}
public void setPurchaseDate(LocalDate purchaseDate) {
	PurchaseDate = purchaseDate;
}
@Override
public String toString() {
	return "MobileCustomer [CustomerName=" + CustomerName + ", MailID="
			+ MailID + ", PhoneNumber=" + PhoneNumber + ", MobileId="
			+ MobileId + ", PurchaseId=" + PurchaseId + ", PurchaseDate="
			+ PurchaseDate + "]";
}



}
