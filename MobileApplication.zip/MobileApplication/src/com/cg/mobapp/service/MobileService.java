package com.cg.mobapp.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.mobapp.bean.MobileCustomer;
import com.cg.mobapp.bean.MobileDetails;
import com.cg.mobapp.dao.Mobiledao;
import com.cg.mobapp.exception.MobileApplicationException;

public class MobileService implements IMobileService {

	
	@Override
	public int CustomerPurchaseDetails(MobileCustomer Cust)
			throws MobileApplicationException {
		// TODO Auto-generated method stub
		return dao.CustomerPurchaseDetails(Cust);
	}
static Mobiledao dao;
	
	public MobileService() {
		// TODO Auto-generated constructor stub
		dao =new Mobiledao();
	}
	

	
	public Mobiledao getDao() {
		return dao;
	}

	public void setDao(Mobiledao dao) {
		this.dao = dao;
	}
	static String gmailpattern="\\b[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";
	static String namePattern = "[A-Z]{1}[a-z]{2,}";	
	//name format pattern
	static String contactPattern = "[0-9]{10}";		
	static String Mobidpattern="[0-9]{4}";
	//phone no format pattern
static String optionPattern="[0-9]{1,}";

	

	
	//validating input name format
	public static boolean validateName(String name)
	{
		boolean flag = false;
		if(name.matches(namePattern))
		{
			flag = true;
		}
		
		
		return flag;
	}
	
	//validating age
	public static boolean validateMail(String mail)
	{
		boolean flag = false;
		if(mail.matches(gmailpattern))
		{
			flag = true;
		}
		return flag;
	}
	//validating option
		public static boolean validateOption(String stt)
		{
			boolean flag = false;
			if(stt.matches(optionPattern)){
			//String stt=String.valueOf(Option);
			int Option=Integer.parseInt(stt);
			if(Option>=1 && Option<=7 && stt.matches(optionPattern))
			{
				flag = true;
			}
			}
			return flag;
		}
	//validating input phone number format
	public static boolean validateContact(String contact)
	{
		boolean flag = false;
		if(contact.matches(contactPattern))
		{
			flag = true;
		}
		return flag;
	}
	public static boolean validateMobid(int mob)
	{
		boolean flag = false;
		String str=String.valueOf(mob);
		if(str.matches(Mobidpattern))
		{
			if(dao.validateMobid1(mob)){
				
			
			flag = true;
			}
		}
		return flag;
	}

	public static boolean validateQuantity(int qty)
	{
		boolean flag = false;
		
		if(qty>0&&qty<100)
		{
			
				
			
			flag = true;
			
		}
		return flag;
	}

	@Override
	public MobileDetails FetchMobileDetails(int Mobileid)
			throws MobileApplicationException {
		// TODO Auto-generated method stub
		return dao.FetchMobileDetails(Mobileid);
	}



	@Override
	public ArrayList<String> getMobileIds() {
		
		return dao.getMobileIds();
	}

	public MobileDetails DeleteMobileData(int Mobileid)
	throws MobileApplicationException{
		
		return dao.DeleteMobileData(Mobileid);
	}



	@Override
	public int priceRangeMobiles(MobileDetails MD)
			throws MobileApplicationException {
		// TODO Auto-generated method stub
		return dao.priceRangeMobiles(MD);
	}



	@Override
	public  boolean validateMobid1(int MobileId) {
		
		return dao.validateMobid1(MobileId);
	}



	@Override
	public List<MobileDetails> viewAllMobilesInPriceRange(MobileDetails MD)
			throws MobileApplicationException {
		// TODO Auto-generated method stub
		return dao.viewAllMobilesInPriceRange(MD);
	}




	
		
		
	

}
