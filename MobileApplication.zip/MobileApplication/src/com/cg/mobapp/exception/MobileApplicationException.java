package com.cg.mobapp.exception;

public class MobileApplicationException extends Exception{
	String message;
	public MobileApplicationException(String msg)
	{
		message=msg;

	
	}
	
	@Override
	public String getMessage()
	{
		return message;
	}

}
