package com.cg.mobapp.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.mobapp.bean.MobileCustomer;
import com.cg.mobapp.bean.MobileDetails;
import com.cg.mobapp.exception.MobileApplicationException;



public interface IMobiledao {
	int CustomerPurchaseDetails(MobileCustomer Cust) throws MobileApplicationException;
MobileDetails FetchMobileDetails(int Mobileid) throws MobileApplicationException;
public ArrayList<String> getMobileIds();
public MobileDetails DeleteMobileData(int Mobileid) throws MobileApplicationException;
public int priceRangeMobiles(MobileDetails MD) throws MobileApplicationException;
public boolean validateMobid1(int MobileId);
public List<MobileDetails> viewAllMobilesInPriceRange(MobileDetails MD) throws MobileApplicationException;
}
