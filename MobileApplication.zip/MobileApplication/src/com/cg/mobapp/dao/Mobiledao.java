package com.cg.mobapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;



















import com.cg.mobapp.bean.*;
import com.cg.mobapp.exception.MobileApplicationException;
import com.cg.mobapp.logger.Moblogger;
import com.cg.mobapp.util.Mobutil;




public class Mobiledao implements IMobiledao {

	
	
	

	Connection con = null;
	static Logger log = Moblogger.log; 				//Reference of logger class pointing to Daologger log
	
	public Mobiledao() {
		// TODO Auto-generated constructor stub
		con = Mobutil.getConnect();			
		//Establishing connection
	}

	public int CustomerPurchaseDetails(MobileCustomer Cust)
			throws MobileApplicationException {
	//	MobileCustomer Cust=new MobileCustomer();

		int PurchaseId = 0;
		try
		{
				PurchaseId = getPurchaseId();			//Getting Unique Patient Id from Sequence
				String sql = "INSERT INTO purchasedetails VALUES(?, ?, ?, ?, ?, ?)";
				PreparedStatement pstmt = con.prepareStatement(sql);
				//many values are passed
				pstmt.setInt(1, PurchaseId);
				pstmt.setString(2,Cust.getCustomerName());
				pstmt.setString(3,Cust.getMailID());
				pstmt.setString(4,Cust.getPhoneNumber());
				LocalDate today = LocalDate.now();
				Date sqlDate = Date.valueOf(today); //to convert todays local date to sql date
				
				pstmt.setDate(5, sqlDate);
				
				pstmt.setInt(6, Cust.getMobileId());
				
				int row = pstmt.executeUpdate();
				
				String upd = "UPDATE mobiles Set Quantity =((select Quantity from mobiles where mobileid=?)-?) where mobileid=?";
				PreparedStatement stmt = con.prepareStatement(upd);
				stmt.setInt(1,Cust.getMobileId());
				stmt.setInt(2,Cust.getQuantity());
				stmt.setInt(3,Cust.getMobileId());
				
				stmt.executeUpdate();
				
				
				
				
				
				
				
				
				
				if(row > 0)
				{
					

					//Logging the New Entry
					log.info("New Entry ->MobileCustomer [CustomerName=" + Cust.getCustomerName() + ", MailID="
			+ Cust.getMailID() + ", PhoneNumber=" + Cust.getPhoneNumber() + ", MobileId="
			+ Cust.getMobileId() + ", PurchaseId=" + PurchaseId + ", PurchaseDate="
			+ Cust.getPurchaseDate() + "]");
				}
				else
				{
					log.error("System Error");
					throw new MobileApplicationException("System Error. Try Again Later.");
					
				}
		}
		catch(SQLException e)
		{
			log.error(e.getMessage());
		}
	
		return PurchaseId;
	}
	
	
	
	
	//Sequence to fetch next value of Patient ID
		private int getPurchaseId() 
		{
			// TODO Auto-generated method stub
			int PurchaseId = 0;
			String sql = "SELECT Purchase_Id_Seq.NEXTVAL FROM DUAL";
			try
			{
				PreparedStatement pstmt= con.prepareStatement(sql);
					ResultSet res = pstmt.executeQuery();
					if(res.next())
					{
						PurchaseId = res.getInt(1);
					}
			}
			catch(SQLException e)
			{
				
				log.error(e.getMessage());
			}
		
		return PurchaseId;
	}

		@Override
		public MobileDetails FetchMobileDetails(int Mobileid)
				throws MobileApplicationException {
		MobileDetails MD=new MobileDetails();
	
			if(validateMobid(Mobileid))			// Checking if Patient id Exists
			{
				try
				{
						String sql = "SELECT * FROM mobiles WHERE mobileid = ?";
						PreparedStatement pstmt = con.prepareStatement(sql);	
						pstmt. setInt(1, Mobileid);
						ResultSet res = pstmt.executeQuery();
						if(res.next())
						{
							MD.setMobileId(res.getInt(1));
							MD.setMobileName(res.getString(2));
							MD.setMobilePrice(res.getInt(3));
							MD.setMobileQty(res.getInt(4));
							
							
							
							//Logging the Searched Entry
							log.info("New Entry -> Mobile ID : "+Mobileid
												+"\nName : "+MD.getMobileName()
												+"\nPrice : "+MD.getMobilePrice()
												+"\nQuantity : "+MD.getMobileQty());
						}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
					log.error(e.getMessage());
					throw new MobileApplicationException(e.getMessage());
				}
			}
			else
			{
				log.error("No Details available for Mobile Id : "+Mobileid);
				throw new MobileApplicationException("\nSorry No Details Found.");
			}
			
			log.info(MD);
			return MD;
		}
		
		
				
		
		
		




		//Check if  exists in database
		public boolean validateMobid(int MobileId)
		{
			// TODO Auto-generated method stub
			boolean flag = false;
			String query = "SELECT * FROM mobiles WHERE mobileid = ?";
			try
			{
				PreparedStatement pstmt = con.prepareStatement(query);	
				pstmt. setInt(1, MobileId);
				ResultSet res = pstmt.executeQuery();
				if(res.next())
					flag = true;
			}
			catch(SQLException e)
			{
				log.error(e.getMessage());
			}
			return flag;
		}

		public ArrayList<String> getMobileIds() {
		String query="SELECT mobileid FROM mobiles";
		ArrayList MobileIds=new ArrayList();
		Statement stat;
		try{
			stat=con.createStatement();
			ResultSet rset=stat.executeQuery(query);
			while(rset.next()){
				String mobileId=rset.getString(1);
				MobileIds.add(mobileId);
			
						}
			}
			catch(SQLException e)
			{
			e.printStackTrace();
		
			}
			return MobileIds;
		}

		@Override
		public MobileDetails DeleteMobileData(int Mobileid) throws MobileApplicationException {
			
			MobileDetails MD=new MobileDetails();
			try{
				String sql = "DELETE  FROM mobiles WHERE mobileid = ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1,Mobileid);
			ResultSet rst = pstmt.executeQuery();
			if(rst.next())
			{
				MD.getMobileId();
				MD.getMobileName();
				MD.getMobilePrice();
				MD.getMobileQty();
			}
			else
			{
				throw new MobileApplicationException("Id not Found");
			}
			con.close();
			}
			catch(SQLException e)
			{
				log.error("SQL ERROR"+e.getMessage());
				throw new MobileApplicationException(e.getMessage());
			}
			return MD;
			
			
		}

		@Override
		public int priceRangeMobiles(MobileDetails MD)
				throws MobileApplicationException {
			int MobileId = -1;
			try{
			String sql="select * from mobiles where price between ? and ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, MD.getMin());
			pstmt.setInt(2, MD.getMax());
			int result = pstmt.executeUpdate();
			
			ResultSet res = pstmt.executeQuery();
		//	for(int i=0;i<res.getRow();i++)
		//	{
			
			
			if(res.next())
			{

			MD.setMobileId(res.getInt(1));
			MD.setMobileName(res.getString(2));
			MD.setMobilePrice(res.getInt(3));
			MD.setMobileQty(res.getInt(4));
			}
	
			
			if(result == 0)
			{
				log.error("unable to insert record ");
				throw new MobileApplicationException("insert Fail");
			}
			//pstmt = con.prepareStatement(QueryMapper.SEQUENCE_QUERY);
			ResultSet rst = pstmt.executeQuery();
			if(rst.next())
			{
				MobileId=rst.getInt(1);
			}
			else
			{
				log.error("Unable to fetch sequence");
				throw new MobileApplicationException("Unable to fetch Sequence");
			}
			con.close();
		}catch(SQLException e)
		{
			MobileId = -1;
			log.error("SQL ERROR"+e.getMessage());
			throw new MobileApplicationException(e.getMessage());
			
		}
			return MobileId;
		}

		@Override
		public boolean validateMobid1(int MobileId) {
			String query="SELECT mobileid FROM mobiles";
			ArrayList MobileIds=new ArrayList();
			Statement stat;
			boolean b=false;
			try{
				stat=con.createStatement();
				ResultSet rset=stat.executeQuery(query);
				while(rset.next()){
					String mobileId=rset.getString(1);
					MobileIds.add(mobileId);
				
							}
				String id=String.valueOf(MobileId);
				b=MobileIds.contains(id);
				}
			
				catch(SQLException e)
				{
				e.printStackTrace();
			
				}
			return b;
		}

		@Override
		public List<MobileDetails> viewAllMobilesInPriceRange(MobileDetails MD)
				throws MobileApplicationException {
			ArrayList<MobileDetails> mb = new ArrayList<MobileDetails>();
			int count = 0;
			try{
				String sql="select * from mobiles where price between ? and ?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, MD.getMin());
			pstmt.setInt(2, MD.getMax());
			int result = pstmt.executeUpdate();
			
			ResultSet rst = pstmt.executeQuery();
			while(rst.next()){
				MobileDetails MBD = new MobileDetails();
				
				MBD.setMobileId(rst.getInt(1));
				MBD.setMobileName(rst.getString(2));
				MBD.setMobilePrice(rst.getInt(3));
				MBD.setMobileQty(rst.getInt(4));
				mb.add(MBD);
			}
		//	else{}
			
			con.close();
			}
			catch(SQLException e)
			{
				log.error("SQL ERROR"+e.getMessage());
				throw new MobileApplicationException(e.getMessage());
			}
			return mb;
			
			
	
		}

		
		
		

	
}
