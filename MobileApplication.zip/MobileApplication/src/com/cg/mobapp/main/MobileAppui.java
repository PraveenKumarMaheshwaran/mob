package com.cg.mobapp.main;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cg.mobapp.service.*;
import com.cg.mobapp.exception.*;
import com.cg.mobapp.bean.*;


public class MobileAppui {
	public static void main(String[] args) throws MobileApplicationException {
		//PatientService service = new PatientService();
		MobileDetails MD=new MobileDetails();
		
		MobileService service=new MobileService();
		int choice1,Mobid,qty;
		String mail,choice ,name,phone,mob;
		boolean flag,flag1,flag2,flag3;
		LocalDate PurchaseDate=null;
		
		try(Scanner sc = new Scanner(System.in))		//try with resource
		{
			do											//do-while loop
			{System.out.println(" Welcome To BigC Mobiles HomePage"
					+ "\n Select the Operation to be Done"
					+ "\n 1.To Insert Customer Purchase Details"
					+ "\n 2.Mobiles Available in store with details"
					+ "\n 3.To get all MobileIds Which exists"
					+ "\n 4.Search For Mobiles Based On Price Range"
					+ "\n 5.Search For Mobiles Based On Price Range"
					+ "\n 6.To delete Mobile Details based on mobileid"
					+ "\n 7.Exit the Application");
				do
				{
				System.out.print("\nPlease Enter a Choice : ");
				choice = sc.next();
				
				flag=service.validateOption(choice);
				if(flag==false)
					System.out.println("Only Enter Your Choice which is present in Menu");	
				}while(flag==false);
				
				System.out.println("\n******************************");
				choice1=Integer.parseInt(choice);
				switch(choice1)
				{
				
				
					case 1 :
						{
							int PurchaseId;
							
							do
							{
								System.out.println("Enter the name of the Customer");
								name=sc.next();
								flag=service.validateName(name);
								if(flag==false)
									System.out.println("Name should be entered in proper format(eg.Matt)");	
							}while(flag==false);
							
							//Patient Age
							do
							{
							System.out.println("Enter Customer MailId : ");
							mail = sc.next();
							flag1=MobileService.validateMail(mail);
							if(flag1==false)
								System.out.println("Email should be in correct formate");
							}while(flag1==false);
							
							//P Phone Number
							do
							{
								System.out.println("Enter Customer phone number : ");
								phone = sc.next();
								flag2=MobileService.validateContact(phone);
								if(flag2==false)
									System.out.println("Phone number should be of 10 digits");
							}while(flag2==false);
							
							do
							{
								System.out.println("Enter  MobileId");
							
								Mobid= sc.nextInt();
								
								flag3=MobileService.validateMobid(Mobid);
								if(flag3==false)
									System.out.println("MobileId Should be of existed one");
							}while(flag3==false);
							
							do
							{
								System.out.println("Enter  Quantity");
							
								qty= sc.nextInt();
								
								flag3=MobileService.validateQuantity(qty);
								if(flag3==false)
									System.out.println("Quantity Should be greater than Zero");
							}while(flag3==false);
							
							
							int num=10;
							MobileCustomer Cust=new MobileCustomer();
							
							Cust.setCustomerName(name);
							Cust.setMailID(mail);
							Cust.setPhoneNumber(phone);
							Cust.setMobileId(Mobid);;
							Cust.setPurchaseDate(PurchaseDate);
							Cust.setQuantity(qty);
							
							try
							{
								//calling Customer PurchaseDetails method
								PurchaseId=service.CustomerPurchaseDetails(Cust);
								System.out.println("Succesfull");
								System.out.println("Customer Purchase Information stored succesfully for "
								+PurchaseId);
								
							}
							catch(MobileApplicationException e)
							{
								System.out.println(e.getMessage());
							
							}
							break;
						}
						
			case 2 :
				
			
				do
				{
					System.out.println("Enter  MobileId to fetch the MobileDetails");
				
					Mobid= sc.nextInt();
					
					flag3=MobileService.validateMobid(Mobid);
					if(flag3==false)
						System.out.println("MobileId Should be of existed one");
				}while(flag3==false);
				System.out.println(service.FetchMobileDetails(Mobid));
				
				
				
		case 3:	 System.out.println(service.getMobileIds());
		case 4:System.out.println("Enter the Price Range");
		System.out.println("Enter Minimum amount");
		int minimum = sc.nextInt();
		System.out.println("Enter Maximum amount");
		int maximum = sc.nextInt();
		MD.setMin(minimum);
		MD.setMax(maximum);
		try{
		service.priceRangeMobiles(MD);
		System.out.println("Mobile Id = "+MD.getMobileId());
		System.out.println("Mobile Name = "+MD.getMobileName());
		System.out.println("Mobile Price = "+MD.getMobilePrice());
		System.out.println("Mobile Quantity = "+MD.getMobileQty());
		}
		catch(MobileApplicationException e){
			System.out.println("Id not Found");
		}
		break;
		case 5:
			try
			{
				System.out.println("Enter the Price Range");
				System.out.println("Enter Minimum amount");
				int mini = sc.nextInt();
				System.out.println("Enter Maximum amount");
				int maxi = sc.nextInt();
				MD.setMin(mini);
				MD.setMax(maxi);
				List<MobileDetails> list = service.viewAllMobilesInPriceRange(MD);
				/*System.out.println("Mobile Id = "+Mbean.getMobileId());
				System.out.println("Mobile Name = "+Mbean.getMobileName());
				System.out.println("Mobile Price = "+Mbean.getMobilePrice());
				System.out.println("Mobile Quantity = "+Mbean.getMobileQuantity());
				//System.out.println("");*/
				for(MobileDetails ref : list)
				{
					System.out.println(ref);
					System.out.println("**********************************\n");
				}
			}
			catch(MobileApplicationException e)
			{
				System.out.println("no rows selected");
			}
			break;
			
		case 6:
			do
		{
			System.out.println("Enter  MobileId to delete the MobileDetails");
		
			Mobid= sc.nextInt();
			
			flag3=MobileService.validateMobid(Mobid);
			if(flag3==false)
				System.out.println("MobileId Should be of existed one");
		}while(flag3==false);
			service.DeleteMobileData(Mobid);		
			}	
						System.out.print("Do you want to continue? 1-Yes  0 - No : ");
						choice = sc.next();
					
					}while(choice1==1);
				}
				

			}

		}

		
		
		
	

